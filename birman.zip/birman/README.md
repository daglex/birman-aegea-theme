# Вдохновленный дизайном блога Ильи Бирмана https://ilyabirman.ru, я создал подобную его блогу тему оформления для движка Эгеи.

Способ установки

Загрузите архив с последней версией темы с Гитхаба и распакуйте его содержимое в папку `user/themes/birman` В настройках вашей Эгеи выберите тему "Бирман", сохраните изменения. При необходимости сбросьте кеши.

В дистрибутиве темы нет шрифтов, которые используются в теме. Их нужно приобрести отдельно.

Теме нужны следующие шрифты:

Gregor 400,GregorIT 400
P22UndergroundCYProBook 400, P22UndergroundHeavy 700
FiraCode-Regular 400

В теме оформления "Бирман" по пути `birman/styles/` создайте папку `fonts` и положите туда файлы шрифтов:

Gregor.woff, GregorIT.woff, Gregor.ttf, GregorIT.ttf
P22UndergroundHeavy.otf, P22UndergroundCYProBook.woff, P22UndergroundHeavy.woff
FiraCode-Regular.woff
