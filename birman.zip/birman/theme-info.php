<?php return array (

  'index' => 0,

  'display_name' => array (
    'en' => 'Birman',
    'ru' => 'Бирман',
  ),

  'colors' => array (
    'background' => '#fff',
    'headings' => '#000',
    'text' => '#000',
    'link' => '#70a0b0',
  ),
  
  'based_on' => 'plain',
  'meta_viewport' => 'width=device-width, initial-scale=1',
  'supports_dark_mode' => true,

); ?>
